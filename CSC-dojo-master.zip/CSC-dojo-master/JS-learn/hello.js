/**
 * http://usejsdoc.org/
 */

console.log('hello..');