define(
({
	buttonOk: "OK",
	buttonCancel: "Скасувати",
	buttonSave: "Зберегти",
	itemClose: "Закрити"
})
);
