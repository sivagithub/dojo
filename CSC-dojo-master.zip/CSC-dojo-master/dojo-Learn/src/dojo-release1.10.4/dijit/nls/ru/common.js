define(
({
	buttonOk: "OK",
	buttonCancel: "Отмена",
	buttonSave: "Сохранить",
	itemClose: "Закрыть"
})
);
