define(
({
	createLinkTitle: "Propietats de l\'enllaç",
	insertImageTitle: "Propietats de la imatge",
	url: "URL:",
	text: "Descripció:",
	target: "Destinació:",
	set: "Defineix",
	currentWindow: "Finestra actual",
	parentWindow: "Finestra pare",
	topWindow: "Finestra superior",
	newWindow: "Finestra nova"
})
);
