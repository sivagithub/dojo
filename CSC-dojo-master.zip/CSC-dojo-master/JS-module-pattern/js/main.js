/**
 * http://usejsdoc.org/
 */


define('js/main', ['js/a'], function(a) {
	
	
	a.doWork();
	
	
});

