define(['dojo/aspect'],function(aspect){
	
	var comp={
			getRandom:function(min,max){
				Math.floor(Math.random()*(max-min+1))+min;
			}
	}
	
	console.log(comp.getRandom(12,25));
	
});