/**
 * New node file
 */
define(['dojo/dom','dojo/on'],function(dom,on){
	
	var b1=dom.byId('b1');
	
	
//	on(b1,'click, mouseover', function(event){
//		
//		console.log(event.type +" event is emitted");
//	});
	
	var i=0;
	
var handler=on(b1,'click', function(event){
		
		console.log(event.type +" event is emitted");
		
		i++;
		
		if(i===5){
			handler.remove();
		}
	});
	
	
	
	
});