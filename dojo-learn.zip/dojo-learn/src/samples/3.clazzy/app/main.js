/**
 * http://usejsdoc.org/
 */

define(['./Person',
        './Employee',
        './Boss',
        './Blizzard',
        './VariableScope',
        './MultipleInheritance',
        './method-chain'
        ],
function(Person,Employee,Boss,Blizzard,NewPerson) {

	//	var p1=new Person({name:'Nag',age:32,address:'CHN'});
	//	console.log(p1.name);
	//	console.log(p1.age);
	//	console.log(p1.address);
	
	//	var e1=new Employee({name:'Nag',salary:1000});
	//	e1.sayName();
	//	console.log(e1.askForRaise());
	
	
	//	var boss=new Boss({name:'Nag',salary:1000});
	//	console.log(boss.askForRaise());
	
	// var yummy=new Blizzard();
	
	//-----------------------------------------------------
	
	//	var p1=new NewPerson({name:'Nag'});
	//	var p2=new NewPerson({name:'Ria'});
	
	//	p1.sayName();
	//	p1.sayName();
	//	
	//	p2.sayName();
	
	//--------------------------------------------------
	
	
	//	console.log("p1 - count:"+p1.count);
	//	console.log("p2 - count:"+p2.count);
	//	
	//	console.log("Total - count:"+NewPerson.totalCount);
		
	//	p1.addFavFood('biryani');
	//	p2.addFavFood('toys');
	//	
	//	console.log(p1.favFood);
	//	console.log(p2.favFood);
	
	

});