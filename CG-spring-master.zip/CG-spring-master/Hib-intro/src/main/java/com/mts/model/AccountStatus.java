package com.mts.model;

public enum AccountStatus {
	ACTIVE, INACTIVE
}
