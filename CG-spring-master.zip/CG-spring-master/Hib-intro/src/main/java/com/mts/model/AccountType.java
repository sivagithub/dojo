package com.mts.model;

public enum AccountType {
	SAVING, CURRENT
}
