package com.mts.service;

public interface TxrService {

	void txr(String fromAccNum, String toAccNum, double amount);

}
