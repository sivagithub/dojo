package com.mts.demo;

public class MyFactory {

	public String getInstance() {
		return "";
	}

}
