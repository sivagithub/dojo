package com.shop.pm;

public class PriceMatrixImpl_v2 {

	public double getprice(String itemCode) {
		// from DB
		// by WS call
		return 200.00;
	}

}
