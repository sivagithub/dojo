package com;

import com.container.SomeContainer;

public class App {

	public static void main(String[] args) {

		SomeContainer sc = new SomeContainer();
		sc.processRequest("/update");

	}

}
