package com;

import com.rpc.RPCProxy;
import com.rpc.RPCTng;

public class App {

	public static void main(String[] args) {

		RPCProxy proxy = new RPCProxy();
		proxy.doTng();

	}

}
