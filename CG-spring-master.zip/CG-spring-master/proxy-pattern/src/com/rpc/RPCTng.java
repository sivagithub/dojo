package com.rpc;

public class RPCTng implements RPC {

	public void doTng() {

		System.out.println("RPC: tng....");

	}

}
