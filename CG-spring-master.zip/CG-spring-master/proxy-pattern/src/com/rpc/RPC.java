package com.rpc;

public interface RPC {
	
	public void doTng();

}
