package com.rpc;

public class Security {

	public void doSec() {
		System.out.println("Security check...");
	}

}
