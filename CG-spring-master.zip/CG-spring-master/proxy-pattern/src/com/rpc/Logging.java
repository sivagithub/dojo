package com.rpc;

public class Logging {
	
	public void doLog(){
		System.out.println("Log....");
	}

}
