package com.shop.bill;

public interface Billing {

	public abstract double getTotalPrice(String[] cart);

}