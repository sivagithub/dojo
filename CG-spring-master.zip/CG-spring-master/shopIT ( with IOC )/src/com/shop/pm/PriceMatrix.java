package com.shop.pm;

public interface PriceMatrix {

	public abstract double getprice(String itemCode);

}