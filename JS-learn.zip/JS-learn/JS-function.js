/**
 * New node file
 */

//IN JS, we can create function 2 ways

// 1. function declaration()
// 2. function expression(fun object will get created at runtime)


//function as values


/*function sayHello(){
	console.log('Hello...');
	
}

var sayHi=sayHello;

sayHi();
*/

// function as arguments

/*function sayHello(greet){
	if(greet){
		greet();
		return;
	}
	console.log("Hello...")
}

sayHello();
sayHello(function(){console.log('ola...')});

*/

//e.g

//var numArry=[1,2,3,4,5,6,7,8,9,10];


// function as return values

/*function tng(){
	console.log('tng.....');
	function learn(){
		console.log('learn....')
	}
	return  learn;
}


var learnFunc=tng();
learnfunc();
learnFunc();*/



/*function reflect(arg1){
	console.log(arguments);
	return arguments['0']
}

console.log(reflect(12,13,14));



// variable scope

function sum(){
	var r=0;
	len=arguments.length,
	i=0;
	while(i<len){
		r+=arguments[i];
		i++;
	}
	return r;
}

console.log(sum(1,2,3,4,5));



function f(){
	console.log('A');
	
}

function f(arg1){
	console.log('B....');
}


f();
*/
/*

* Js function
* 
* ---> variable 'hoisting' / lifting up
*
*/

/*var v=100;  //global scope

function display(){
	//var v=200; //function scope
	console.log(v);
	
	var v=200;
}

display();
*/

//best practice : while writing func, always follow ' single var design pattern'



/*function f(){
	k=200;
}
f();

console.log(k);
*/

//-------------------------

/*

*'this' keyword
*
*why we need 'this' keyword?
*
*/

/*var person={
		name:'siva',
		sayName:function(){
			console.log('im'+this.name);
		}
};*/

//person.sayName();

/*var np=person;
person={name:'riya'};
np.sayName();

*/
//-----------------------------------------

/*global.name='GLOBAL';

function sayNameforAll(){
	console.log('in'+this.name);
}


//var p1={name:'Nag', sayName: function(){console.log('in'+this.name);}};

//var p2={name:'Nag', sayName: function(){console.log('in'+this.name);}};

var p1={name:'Nag', sayName: sayNameforAll};

var p2={name:'siva', sayName: sayNameforAll};

sayNameforAll();
p1.sayName();
p2.sayName();*/




/*var util={
		sayName:function(message,form){
			console.log(message+' in '+this.name+"-"+from);
			
		}
};


var p1={name:'Nag'};
var p2={name:'ola'};


util.sayName.call(p1,"Hello","BLR");

util.sayName.call(p2,"reddy","CHN");

var newF=util.sayName.bind(p1,"Ola","CHN");

newF();
newF();
newF();*/

//-------------------------------




function Person(name,age){
	this.name=name;
	this.age=age;
	this.sayName=function(){
		console.log('im '+this.name);
	};
}

var p1=new Person('Nag',32);
var p2=new Person('Siva',29);

p1.sayName();

p2.sayName();



//-----------------------------


/*
 * 
 * In JS, we can invoke function in 4 ways
 * 
 * 1. function-invocation
 * 2. method - invocation
 * 3. call/bind- invocation
 * 4. constructor - invocation
 * 
 * 
*/

//-------------------------

// JS -Function 'Closure'


function tng(){
	console.log('tng.....');
	var info='Js notes';
	function learn(){
		console.log('learning with '+info);
	}
	return learn;
}

var learnFunc=tng();


learnFunc();
learnFunc();



//-------------------


function init(){
	var count = 0;
	
	return {
		doCount:function(){
			count++;
		},
		getCount:function(){
			return count;
		}
	};
}

var counter=init();

counter.doCount();
counter.doCount();

console.log(counter.getCount());



//------------------------------IIFE

var counter = (function(){
	
var count = 0;
	
	return {
		doCount:function(){
			count++;
		},
		getCount:function(){
			return count;
		}
	};
	
})();

counter.doCount();
counter.doCount();

console.log(counter.getCount());



//---------------------------------




var trainer={
		name:"Nag",
		doTeach:function(){
			console.log(this.name + " teaching JS");
			var that = this;
			
			function learn(){
				console.log(this.name + " learning JS from "+that.name);
			}
			
			var emp = {
					name:"CSC"
			};
			
			learn.call(emp);
		}

		
		
		
};

trainer.doTeach();

//var newTrainer={name:"kishore"};

//trainer.doTeach.call(newTrainer);


/*
 * Inheritance in JS
 * 
 * 
 * 
*/










