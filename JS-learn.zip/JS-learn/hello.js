/**
 * New node file
 */



//var name="Siva";
//console.log(typeof name);

//var count = 10;
//console.log(typeof count);
//var cast=12.12;
//console.log(typeof cast);


//boolean

//var v;
//console.log(typeof v);
//
//var o=null;
//console.log(typeof o);

//console.log('5'==5);
//console.log('5'=== 5);
//
//console.log(undefined == null);
//console.log(undefined === null);



//reference





