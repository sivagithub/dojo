/**
 * New node file
 */
/*
 * Inheritance in JS
 * 
 * In Js we can implement 'prototype' based inheritance
 * 
*/


function Person(name,age){
	this.name=name;
	this.age=age;
//	this.sayName=function(){
//		console.log('im '+this.name);
//	};
}


Person.prototype.sayName=function(){
	console.log('im '+this.name);
};

var p1=new Person('Nag',32);
var p2=new Person('Siva',29);


p1.sayName();

