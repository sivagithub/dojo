/**
 * New node file
 */



/*var person={
		name:'Siva',
		
};

//to check property existence
if(person.name){
	console.log('name property exist in person-obj');
}

//or

if("name" in person){
	console.log('name property exist in person-obj');
}*/

//enumurating js-obj properties
//var person={
//		name:'Siva',
//		age:29
//		
//};
//
//for(var prop in person){
//	
//	if(person.hasOwnProperty(prop)){
//	console.log(prop+":"+person[prop]);
//	}
//}
//
//


//---------------------

/*
 * js-objt we can hava 2 types of properties
 * 
 * a. data
 * 

*/

//var person={
//		_name:'Siva',//data property
//		set name(newName){  //accessor property
//			console.log('set...');
//			if(newName){
//				this._name=newName;
//			}
//		},
//
//		get name(){
//			console.log('get...');
//			return this._name;
//		}
//
//
//};
//
////person._name='';
////console.log(person._name);
//
//person.name='new Siva';
//console.log(person.name);



//---------------------

//"use strict"

/*var person ={name:'siva'};
Object.defineProperty(person, 'name', {configurable:false, writable:false});

//Object.defineProperty(person, 'name', {configurable:true});
//delete person.name;

person.name='dsfasdf';

console.log(person.name);*/


//--------------------

/*var person ={name:'siva', age:29};
//Object.preventExtensions(person);

Object.seal(person);
Object.freeze(person);  //immutable

person.newProp="abc";
delete person.name;
person.name='dsfasdf';*/







//MDN javascript website














