/**
 * New node file
 */

//var name="Siva";
//console.log(typeof name);

//var count = 10;
//console.log(typeof count);
//var cast=12.12;
//console.log(typeof cast);


//boolean

//var v;
//console.log(typeof v);
//
//var o=null;
//console.log(typeof o);

//console.log('5'==5);
//console.log('5'=== 5);
//
//console.log(undefined == null);
//console.log(undefined === null);



//reference





//var person=new Object();
//
//person.name='Siva';
//person.age=29;
//
//person.sayName=function(){
//	console.log('im '+this.name);
//};


//console.log(person.name);

//person.sayName();

//delete person.age;

//console.log(person.age);

//using delete keyword we can only delete object properties



/*
 * 
 * 
 * 
*/

// literal-style

/*var newPerson={
		name 	:'siva',
		age		:29,
		sayName  :function(){
			console.log('im '+this.name);
		}
};

newPerson.sayName();
*/

//RegExp
//var re=new RegExp("\\d");
//console.log(re.test("abc"));
//
//
////literal style
//var newRe=/\d/;
//console.log(newRe.test("12345656"));


//========================

/*var add=new Function("n1","n2","var result=n1+n2;return result");

console.log(add(12,13));


//literal

function add(n1,n2){
	var result=n1+n2;
	return result;
}

console.log(add(12,13));*/


//how to access object properties?

/*
 * 2 ways
 * 
 * -->'.' notation
 * -->'[]' notation
 * 
 *
*/

/*var person={
		'full-name':'sivaiah',
		age:32
};

console.log(person['full-name']);
console.log(person.age);

*/

//---------------------------


//Primitives as Objects

var name='siva';
var newName=name.toUpperCase();
console.log(newName);


//var boo=new Boolean(false); // never create primitives as objects

var boo= false;

if(boo){
	console.log("now we go lunch");
}else{
	console.log("we wont");
}


























