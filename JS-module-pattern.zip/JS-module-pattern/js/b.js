/**
 * New node file
 */

define('js/b', ['js/c'], function(c){
	
	
	c.doWork();
	
	var mod={
			doWork: function(){
				console.log('B....');
			}
	};
	
	return mod;
});