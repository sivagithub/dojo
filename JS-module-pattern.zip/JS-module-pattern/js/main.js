/**
 * New node file
 */

define('js/main',['js/a'], function(a){
	a.doWork();
});