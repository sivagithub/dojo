/**
 * New node file
 */


define('js/a', ['js/b'], function(b){
	
	
	b.doWork();
	
	var mod={
			doWork: function(){
				console.log('A....');
			}
	};
	
	return mod;
});