/**
 * New node file
 */
define('js/c', [], function(){
	
	

	
	var mod={
			doWork: function(){
				console.log('C....');
			}
	};
	
	return mod;
});